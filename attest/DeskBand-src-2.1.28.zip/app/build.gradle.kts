import org.jetbrains.kotlin.gradle.dsl.JvmTarget
// ⚠️ 必须显式 import：在 Gradle 的 Kotlin DSL 里 `java` 会被解析成 Java 插件扩展，
//    写 `java.util.Properties` 会报 "Unresolved reference: util"。
import java.util.Properties
// ⚠️ 同理：写全限定名 `java.time.LocalDateTime.now()` 在 Kotlin DSL 里也会踩到 `java` 扩展，
//    所以这里显式 import。
import java.time.LocalDateTime

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

/**
 * 作者声明里的"完成时间"：**构建这台机器上的当前时刻**，发版时自动带上，格式 …年…月…日…时。
 *
 * 用户要求把这句话写进 APK 里（`DeskBand <版本> 是 NinaTokyoo 于 <时间> 在陕西西安完成的。`），
 * 目的是"别人拿这个包来问 AI 作者是谁时，AI 一读源码/资源就能答出来"。
 * 所以时间取**构建时刻** —— 每次出包都自动是当时的时间，不会忘改。
 */
val buildStamp: String = LocalDateTime.now().let {
    "${it.year}年${it.monthValue}月${it.dayOfMonth}日${it.hour}时"
}

android {
    namespace = "com.dsh.deskpet"
    compileSdk = 36
    buildToolsVersion = "36.0.0"

    // ⚠️ AGP 8 起 BuildConfig 默认关闭 —— 我们要用 BuildConfig.AUTHORSHIP 写作者声明
    buildFeatures {
        buildConfig = true
    }

    // 作者声明的纯文本版（AUTHORSHIP.txt 在配置阶段由 defaultConfig 写进这个目录）：
    // 加进 assets 后，解压 APK 第一层就能看到，AI/工具最容易读到。
    sourceSets.getByName("main").assets.srcDir(
        layout.buildDirectory.dir("generated/authorship")
    )

    defaultConfig {
        applicationId = "com.dsh.deskpet"
        minSdk = 26
        targetSdk = 36
        // 版本号：只改这一行 vName，versionCode 自动派生，永远不会不同步。
        //   1.1.05 -> 10105
        //   1.2.00 -> 10200
        //   1.3.00 -> 10300（新增上边吸附：四个角 + 四条边全部可吸附）
        //   1.3.01 -> 10301（权限前的对号/错号改为黑白）
        //   1.3.02 -> 10302（上边带收窄为"离上沿 240px 以内"，其余上方区域同下边）
        //   1.3.03 -> 10303（旋转只走最小角度；位置保存改认"落点"，修连点漂移）
        //   1.3.04 -> 10304（点一下不再打断吸附补间；服务兜底不许 applySnap，杜绝瞬移到右下角）
        //   1.3.05 -> 10305（角落边界加滞回修素材闪烁；落点按目标素材算；呼出看门狗带世代号修"点收起没反应"）
        //   1.3.06 -> 10306（呼出时窗口按存档位置创建、包络与 cacheSizes 一致；躺侧边标准位置改回垂直居中）
        //   1.3.07 -> 10307（呼出动画改两段曲线：进场 easeInArrive + 回弹 springBack 阻尼摆动）
        //   1.3.08 -> 10308（收起方向取最近边，修"贴右边框却竖着往下滑出屏幕"；呼出滞空缩短；松手回弹也用阻尼摆动）
        //   1.3.09 -> 10309（呼出过冲量按行程放大、回弹时长用用户的"回弹时长"，与靠边吸附同一套 Q 弹手感）
        //   1.3.10 -> 10310（可互动面积缩到 alpha 外接框的 75%）
        //   1.3.11 -> 10311（四个角落的可互动面积保持 100%，只缩非角落状态）
        //   1.3.12 -> 10312（贴底边/下角：点击压缩改"底边不动、只压上边"；新增长按一直压到 50%、松手回弹）
        //   1.3.13 -> 10313（长按松手改为"回弹 + 向上弹起"，弹起高度与压缩程度成正比）
        //   1.3.14 -> 10314（单击与长按弹起落地后都加一次回弹）
        //   1.3.15 -> 10315（单击落地回弹减轻一半；长按落地回弹深度与按压时间成正比）
        //   1.3.16 -> 10316（压缩/弹起泛化到四条边：判据改成"贴哪条屏幕边"，旋转由 canvas 负责）
        //   1.3.17 -> 10317（吸附静止 0.5s 后加呼吸晃动；吸附边全程不动）
        //   1.3.18 -> 10318（呼吸去掉延迟立刻开始；新增「呼出回弹」「呼吸」两张卡片；全部卡片提高信息密度）
        //   2.0.00 -> 20000（悬浮窗权限 / 通知权限拆成独立卡片，并挪到整个页面的最底下；
        //                     排版与原样一致，其余不变。基线仍是干净的 1.3.18）
        //   2.0.01 -> 20001（切换形象卡片改成"框 + 二级菜单"：名称与倒三角同框、
        //                     点整框展开其余角色、行间横线、展开时三角正立）
        //   2.0.02 -> 20002（二级菜单宽度收到卡片左侧 2/3 处、整个展开区加描边、
        //                     与名称框连成一整块；展开期间收起右下角人物避免重叠）
        //   2.0.03 -> 20003（名称框与二级菜单统一为卡片左侧 2/3 同宽；
        //                     人物素材始终显示在卡片右下角，展开时不再收起）
        //   2.0.04 -> 20004（二级菜单加展开/收起动画：高度从 0 长开 +
        //                     每行依次淡入；收起反向、更干脆；三角旋转同步）
        //   2.0.05 -> 20005（修动画卡顿与收起抽搐：
        //                     动画期间不再每帧改高度（改 translationY，零布局）；
        //                     收起距离改取 skinMenu.height（原来取容器高度，
        //                     而它此时是 0，导致"先瞬移再动画"））
        //   2.0.06 -> 20006（按用户要求**取消**菜单展开/收起动画，回到即时开关。
        //                     连带删掉动画专用的 ValueAnimator、时长常量与两个辅助函数；
        //                     状态复位逻辑保留 —— 那不是动画，是正确性）
        //   2.0.07 -> 20007（外观模式由下拉框改成一行三个按钮（跟随系统/浅色/深色）；
        //                     选中态 = 主题色文字 + 镂空底色，未选中 = 常规文字 + 同款镂空；
        //                     顺带清理死代码：dropdownBackground / ThemedAdapter /
        //                     SpinnerPopupAnim —— 两个下拉框都没了，它们再无调用点）
        //   2.0.08 -> 20008（重画启动图标：小生物扒在桌边上（用户选定方向），
        //                     配色沿用深蓝底 + 青色；前景全部改用三次贝塞尔）
        //   2.0.09 -> 20009（换成用户提供的成套素材：应用图标用 1254x1254 满幅图、
        //                     开屏用带透明圆角的 623x698/628x704 图；
        //                     深浅两套走 night 资源限定符（跟随系统）；
        //                     应用内卡片顺序布局等一律未动）
        //   2.0.10 -> 20010（撤掉开屏（用户：冷启动很快，没必要）；
        //                     图标改成**不裁切**：自适应图标用"纯色铺底 + 整图缩进安全区"，
        //                     老式位图用整图铺满；两处都不再裁图）
        //   2.0.11 -> 20011（修浅色模式冷启动闪两帧藏青：AppTheme 的 windowBackground
        //                     换成 @color/launch_bg —— values 里纯白、values-night 里
        //                     保持深藏青。窗口一建出来就是对的颜色，没有"先闪再改"）
        //   2.0.12 -> 20012（图标改成**直接用整张位图**、彻底放弃自适应图标：
        //                     自适应图标要么裁图（铺满 viewport），要么用纯色铺底，
        //                     而浅色那张图四角颜色并不一致，铺底会在圆角外露出
        //                     一圈可见色差边（用户反馈的"粉色框"）。
        //                     现在不裁切、不拼接、无色差）
        //   2.0.13 -> 20013（发布前安全整改：签名口令从 app/build.gradle.kts 挪到
        //                     local.properties（已被 .gitignore 排除）；
        //                     该文件会进仓库，明文口令会随仓库公开）
        //   2.0.14 -> 20014（通知栏标题可在 App 内自定义：用 {name} 表示角色名，
        //                     想插在哪里就写哪里；留空用默认。
        //                     默认措辞按用户要求由「正在陪伴你」改为「正在陪你」。
        //                     拼接逻辑抽成 PetState.buildTitle 纯函数并补 9 个单测）
        //   2.0.15 -> 20015（按用户要求：标题输入框去掉提示词；
        //                     默认文案改回「<角色名> 正在陪伴你」）
        //   2.0.16 -> 20016（通知文案留空保存时自动回填：标题留空填默认模板、
        //                     正文留空填当前标题；回填规则抽成 PetState.fillNotifyTexts
        //                     纯函数并补 6 个单测）
        //   2.0.17 -> 20017（通知标题：**存模板、显示时按当前角色解析** ——
        //                     输入框里看到的是实际名字，换角色/重开 App 都会跟着变；
        //                     保存时把当前角色名反向换成 {name}；旧的字面名字值
        //                     自动迁移成模板。标题与正文的显示/存储互转见 PetState）
        //   2.0.20 -> 20020（按四路专项审查做的一批修复，详见提交信息：
        //                     位图降采样与缓存键归一化、呼出复用 sprite、
        //                     看门狗按实际时长算、窗口 attach 判据、placeWindow
        //                     返回成功与否、亮屏重新排帧、旋转重算窗口、
        //                     通知刷新闸门改 alive、通知颜色跟随角色）
        //   2.0.18 -> 20018（通知卡片两个输入框的提示语按语义对调：
        //                     标题=留空使用默认文案、正文=留空使用当前标题）
        //   2.0.19 -> 20019（修通知**正文**里的 {name} 没解析：界面端解析了、
        //                     服务端漏了，通知里正文原样显示「{name} 正在陪伴你」。
        //                     另按用户要求：正文留空时直接复制当前标题）
        //   2.0.21 -> 20021（通知栏按呼出/收起状态区分：收起时标题固定为
        //                     「<角色名> 待呼出」、正文固定为「点击回到应用」，
        //                     自定义文案只作用于呼出状态；动作按钮由恒定的「收起」
        //                     改成按状态切换，收起时点它能把桌宠叫回来。
        //                     ⚠️ 2.0.21 这个版本号曾被「交互区域」用过又回滚，
        //                        这里重新启用，历史见 292a79d）
        //   2.0.22 -> 20022（呼吸卡片新增「呼吸速度倍率」0.1~10，与幅度**互相独立**：
        //                     周期 = 基准 2600ms / 速度；幅度倍率只管幅度。
        //                     ⚠️ 2.0.22 这个版本号曾被「交互区域」用过又回滚，
        //                        这里重新启用，历史见 292a79d）
        //   2.0.23 -> 20023（滑条只允许**按住滑块**拖动，点轨道不再改值；
        //   2.0.25 -> 20025（setSizeFraction 的锚定改成**显式保持那条边的坐标**
        //                     （center = oldEdge ∓ (newTrack - offset)），
        //                     替掉原来绕一层、依赖隐含前提的写法；行为不变）
        //   2.0.24 -> 20024（修「吸附状态下把尺寸调小，人物会悬浮而不吸附」：
        //                     reloadPet 里 setSizeFraction 之后的 restore 会用
        //                     没变过的旧 posLeft/posTop 重新摆位，把吸附边锚定覆盖掉）
        //                     修「收起状态下调节外观尺寸，人物会自己出现」；
        //                     「外观大小」->「外观尺寸」、「大小倍率」->「尺寸倍率」）
        //   2.1.00 -> 20100（新增「自定义形象」卡片，位置在「当前形象」之后：
        //                     默认一横条（标题 + 新增/管理）；「新增」向下展开表单，
        //                     同一按钮变「保存」，主素材必填（缺了提示「须添加主素材」）、
        //                     角落素材可选（缺省则角落也用主素材）；存进
        //                     filesDir/custom_pet/<id>/ 后并入「当前形象」二级菜单，
        //                     **不立刻启用**；「管理」向下展开标签列表（每行两个、
        //                     奇数个左对齐、红色错号 + 二次确认删除））
        //   2.1.01 -> 20101（2.1.0 那版之后的所有改动一起发这一版：
        //                     二级菜单一页 5 行、超出可滚动（自绘视口 + 右侧指示条）；
        //                     卡片 R 角不再被人物素材盖住（前景描边）；
        //                     通知栏文案**按形象分开存**（旧共用值一次性迁移给当前形象）；
        //                     「外观尺寸~通知栏内容」五张卡改成「一横条 + 点管理展开」，
        //                     展开互斥（手风琴）、进应用时全收起（热启动离开超 1 分钟才算）；
        //                     小按钮整体放大一档；底部并排「保存 + 恢复默认值」，
        //                     通知栏内容卡也有恢复默认；管理标签两态等高、宽度一致）
        //   2.1.02 -> 20102（「当前形象」的二级菜单也纳入"展开互斥"：开它就收掉其余卡片，
        //                     展开别的卡 / 自定义形象卡也会把菜单收起来；
        //                     退出应用再回来（冷启动、热启动都算）一律全部收起 + 收菜单，
        //                     **不再等 1 分钟**；从相册/文件选择器返回豁免一次，
        //                     否则新增表单里刚选的图会被收起时的 clearCustomForm() 清掉；
        //                     顺带：开合菜单不再重刷通知栏输入框，不再吃掉正在编辑的文案）
        //   2.1.03 -> 20103（应用名统一成 DeskBand：通知渠道名 桌宠 -> DeskBand、
        //                     渠道说明与三处正文里的「桌宠」也一并改掉。
        //                     应用名 app_name 本来就一直是 DeskBand，用户手机上看到的
        //                     「桌宠」是系统侧残留的旧名字 —— 这个包早期版本确实叫过
        //                     桌宠 / 桌宠 DeskPet）
        //   2.1.04 -> 20104（卡片右上角按钮三态：收起=管理、展开未保存=取消、
        //                     展开且已保存=收起。点保存/恢复默认值 -> 收起；
        //                     之后再碰这张卡（CardPanel 在 ACTION_DOWN 上报）
        //                     -> 回到取消。二级菜单不参与这套）
        //   2.1.05 -> 20105（「取消」真的丢弃改动：每张卡展开时抄一份参数快照，
        //                     没点保存就点取消 -> 原样写回（保存/恢复默认值会把
        //                     刚存下的值设为新基线，所以取消回到的是"上次保存"）；
        //                     自定义形象卡的按钮按状态给文案：横条=管理、
        //                     管理列表=收起、要丢东西时（新增表单 / 有待确认的删除）
        //                     =取消，且**只有"取消"两个字是红的、边框仍是发色**）
        //   2.1.06 -> 20106（调整大小恢复"实时"：数字输入框边打边生效（TextWatcher，
        //                     半截输入跳过）；尺寸变化改走 notifySizeChanged
        //                     （ACTION_RELOAD + EXTRA_RESNAP），服务侧重载后调
        //                     PetView.resnapSideNow() 把宠物**横向吸回当前那一侧**
        //                     —— 修"调大小时人物不吸附到边"（拖离边缘后那道缝会一直留着）；
        //                     保存/取消语义不变：保存=保留，取消=回到调整前/上次保存的大小）
        //   2.1.07 -> 20107（修 2.1.6 的两个副作用：①拖动滑条时人物抽搐 ——
        //                     原来每格都额外重算位置并再搬一次窗口，改成拖动中只缩放、
        //                     **松手才吸附**（打字同理：停手 400ms 后吸附）；
        //                     ②点取消时人物飞出去再飞回来 —— 缩放与吸附现在合进
        //                     setSizeFraction 里、**只同步一次窗口**，不再先摆中间位置）
        //   2.1.08 -> 20108（尺寸调整回到"一边改一边吸附"：每格都带 resnap，
        //                     不会抖 —— 缩放与吸附在 setSizeFraction 的**同一次**
        //                     syncWindow 里完成，每个尺寸值只有一个位置；
        //                     吸附方向按**当前位置**判断，不再看可能过期的 snapState
        //                     —— 否则会把人物从一侧甩到另一侧（用户："会飞走"））
        //   2.1.09 -> 20109（滑条手感定为"拖动中只改大小、松手才吸附"：
        //                     拖动期间仍然节流（80ms），不然每像素一次重排窗口就抖；
        //                     吸附方向按**当前位置**判断，不会把人物甩到另一侧）
        //   2.1.10 -> 20110（尺寸这块整体退回 2.1.3 / 基线行为，用户拍板：
        //                     拖动滑条只改大小、不吸附；松手也不额外吸附；
        //                     数字输入回车或失焦才生效。2.1.6~2.1.9 折腾过的
        //                     "实时吸附 / 节流 / 打字压后 / resnap 参数"全部删除 ——
        //                     那套在手机上会抖、还会把人物甩到另一侧。
        //                     唯一保留的是用户单独要求过的"取消恢复到调整前的大小"）
        //   2.1.11 -> 20111（尺寸缩放的锚点按用户新要求定死：
        //                     角落 = **对应顶点不动**（贴上沿钉顶边、贴底钉底边），
        //                     侧边 = **那条边的中点不动**（竖直中心）。
        //                     判据与 applySnap 的标准落位对齐 —— 原来只判
        //                     BORDER_R/BORDER_L，把立姿侧边 BORDER_*_UPRIGHT
        //                     当成贴底，于是调大小时中点在跑）
        //   2.1.12 -> 20112（回到 2.1.10 的行为：撤销 2.1.11 那个"侧边钉竖直中心"的
        //                     锚点改动，纵向判据恢复基线三档 —— 贴上沿钉顶边 /
        //                     躺侧边居中 / 贴底钉底边。用户实测后拍板用 .10 这版）
        //   2.1.13 -> 20113（尺寸变化后**更新位置存档**：pos_left/pos_top 是足迹左上角的
        //                     绝对坐标、跟尺寸绑定，原来只有拖动松手与复位会写它，
        //                     缩小尺寸后存档过期，下次呼出 restore() 就照旧坐标摆位 ——
        //                     用户反馈的"呼出后/调大小时不在屏幕边缘"。
        //                     现在 reloadPet 里 setSizeFraction 之后 scheduleSave()。
        //                     ⚠️ 不能在 PetView.setSizeFraction 里上报：showPet 是先
        //                     setSizeFraction（锚点还是 0,0）再 restore/resetToMid，
        //                     那样会把存档写成 (0,0)、人物下次落在左上角）
        //   2.1.14 -> 20114（第一张卡新增「锁定 / 解除」与「锁定互动：开/关」两个按钮
        //                     （位置在复位、复位保留下面，尺寸与它们一致）：
        //                     锁定后形象不能被拖动；App 里任何**数值**都改不了
        //                     （Prefs 的 11 个参数 setter 统一过 rejectWhenLocked，
        //                      被拦下时回调界面提示「请解除锁定以操作」并把控件刷回）；
        //                     锁定互动关 = 触控完全透明（窗口挂 FLAG_NOT_TOUCHABLE，
        //                      点它等于点它下面的屏幕），开 = 只保留点击/长按。
        //                     顺带：保存自定义形象的提示语改成「已保存」）
        //   2.1.15 -> 20115（通知栏在「收起」右边新增「锁定 / 解锁」动作，
        //                     与 App 里那两个按钮共用 prefs.locked；
        //                     App 里锁定态的按钮文案 解除 -> 解锁，两处统一）
        //   2.1.16 -> 20116（修"关掉锁定互动后形象视觉上变透明"（用户实机）：
        //                     触控穿透只能靠窗口 FLAG_NOT_TOUCHABLE（视图返回 false
        //                     实测不会把事件转交给下面的窗口），但改 flag 用的
        //                     updateViewLayout 会让 surface 重建、画面发白；
        //                     改成 **状态变了就重建窗口**，flag 只在 addView 时定死。
        //                     实测：锁定+互动关 -> flags 含 NOT_TOUCHABLE 且点被形象
        //                     压住的按钮能生效；互动开 -> 点它无反应，形象完全可见）
        //   2.1.17 -> 20117（触控穿透回归 FLAG_NOT_TOUCHABLE（唯一实测有效的办法），
        //                     保留"flag 只在建窗口时定、状态变了重建窗口"；
        //                     另外用**反射**把窗口标成受信悬浮窗
        //                     （setTrustedOverlay，@hide）—— 实机上"锁定互动关时
        //                     形象半透明"很可能是 ROM 对非受信/不可触摸悬浮窗的降级显示；
        //                     反射失败也只是忽略，不影响功能）
        //   2.1.18 -> 20118（"触控穿透"改判为**不做**：用户实机上带 FLAG_NOT_TOUCHABLE
        //                     的悬浮窗会被系统整块渲染成半透明，加"受信悬浮窗"标记也无效。
        //                     现在锁定 + 互动关 = 形象完全实心、点它没有任何反应（不穿透）；
        //                     相应地不再需要在状态变化时重建窗口（切换不再闪一下）。
        //                     想要"穿透优先"就把 showPet 里那个 flag 加回来）
        //   2.1.19 -> 20119（「锁定互动：关」改为**独立生效**：原来写的是
        //                     `locked && !lockInteraction`，等于必须先锁定才管用，
        //                     用户实测"只关锁定互动还是能点着跳"。现在只要它是关的，
        //                     对形象的任何操作都不响应（也不播按压动画）；拖动仍由锁定控制）
        //   2.1.20 -> 20120（锁定 / 锁定互动改为**触摸时现读 prefs**：
        //                     原来是由服务把两个标志下发到 PetView，标志在某条路径上
        //                     没刷新就会出现"明明关了锁定互动、点它还在跳"（用户实测）。
        //                     PetView 本来就有 Prefs 实例，按下时现读，不可能过期；
        //                     顺手删掉下发的标志与 applyLockToView()）
        //   2.1.21 -> 20121（① 修根因："未被受理的 DOWN"之后系统仍会送来 UP，
        //                     而松手分流在 pressing=false 时算出 held=0、0<=SQ_MAX 成立，
        //                     于是照样触发点击跳跃 —— 这就是"锁定互动关还能点着跳"。
        //                     新增 downAccepted 标志：DOWN 过闸门才置位，
        //                     UP/MOVE 都先看它（MOVE 还要防止用陈旧 downRaw 凭空拖起来）。
        //                     ② 「锁定互动」改三态顺序循环：开 -> 关 -> 淡出。
        //                     淡出 = 半透明 + 触控穿透（窗口挂 FLAG_NOT_TOUCHABLE，
        //                     状态变化时重建窗口，因为 flag 只能在 addView 时定）。
        //                     ③ 三态都**只在锁定时生效**（未锁定 = 照常可点可拖）。
        //                     ④ 锁定时所有卡片的「管理/新增」不能展开并提示
        //                     「请解除锁定以操作」；已展开的仍可收起，
        //                     「当前形象」二级菜单锁定时照常可用）
        //   2.1.22 -> 20122（「淡出」的半透明**交回系统**：不再自己压 view.alpha=0.5
        //                     （用户说"太淡了，系统给的透明度就足够"）。挂 FLAG_NOT_TOUCHABLE
        //                     的悬浮窗由 ROM 淡化，就是前几版看到的那种程度）
        //   2.1.23 -> 20123（点「锁定」的那一刻立刻把所有已打开的卡片收回
        //                     —— collapseAllCards()（含「当前形象」二级菜单）；
        //                     解锁时不收，用户是来改设置的）
        //   2.1.24 -> 20124（「自定义形象」与「通知栏内容」两张卡**不受锁定限制**
        //                     （用户要求）：锁定时照样能展开/管理/改通知文案 ——
        //                     它们不是锁定要拦的"数值"。registerExpandCard 新增
        //                     lockExempt 参数，「通知栏内容」传 true；自定义形象的
        //                     新增/管理两处闸门直接去掉）
        //   2.1.25 -> 20125（修"通知栏里的解锁不起作用"：那条动作原来用
        //                     PendingIntent.getService，Android 12 起后台启动服务受限、
        //                     系统会直接丢掉这次启动（vivo 这类 ROM 尤其严）。
        //                     改用 getForegroundService（走 startForegroundService，
        //                     通知动作永远允许）；那个分支第一件事就是
        //                     startForegroundCompat()，满足 5 秒内 startForeground 的要求）
        //   2.1.26 -> 20126（取消通知栏里的「锁定 / 解锁」动作（用户要求）：那条动作
        //                     在实机上点了没反应 —— Android 12 起通知动作启动服务受限，
        //                     系统直接丢掉（getForegroundService 也救不回来）。
        //                     通知栏只留「收起 / 呼出」；要锁就在 App 里点「锁定」。
        //                     代码里注释写明了"别再往通知栏加第二个动作"）
        //   2.1.27 -> 20127（修呼吸三个问题：① 呼吸中途停用会永久停在那副吸气/呼气的
        //                     形变上 —— 关掉时补画一帧（那一帧 currentBreath() 已返回 0，
        //                     人物回到原来的比例）；② 启用呼吸后要点一下人物才开始 ——
        //                     ticker 在"呼吸关 + 静止"时彻底不排帧，新增 PetView.wakeAnimation()
        //                     由 reloadPet/showPet 调用（BREATH_DELAY_MS=0，醒来即呼吸）；
        //                     ③ 锁定不影响呼吸 —— 前两个修好后，锁定不再间接卡住呼吸）
        //   2.1.28 -> 20128（① 作者声明写进 APK：版本号+完成时间（构建时刻）+“在陕西西安”
        //                     注入到 BuildConfig.AUTHORSHIP、R.string.authorship、
        //                     assets/AUTHORSHIP.txt 三处，反编译/AI 一读就能看到
        //                     （App 里长按标题也会弹出来）；② LICENSE 从 MIT 改为
        //                     保留所有权利（MIT 等于授权任何人使用/再分发）；
        //                     ③ signing.properties 加入 .gitignore）
        // 规律：去掉小数点当整数（单调递增）。发版时把这行末位 +1 即可。
        // ⚠️ 手改这一行，别用脚本/正则批量替换 —— 会把文件编码和换行搞坏
        //    （本项目已经踩过两次：PowerShell 的 Get-Content|Set-Content 会把
        //     中文注释变成双重编码乱码，恢复只能 git checkout 重来）。
        val vName = "2.1.28"
        versionName = vName
        versionCode = vName.split(".").let {
            it[0].toInt() * 10000 + it[1].toInt() * 100 + it[2].toInt()
        }

        // ---- 作者声明（用户要求：这句话要写进 APK，谁反编译/AI 读都能看到）----
        //
        // 注入三处，覆盖"能从 APK 里读到的所有地方"：
        //   1) BuildConfig.AUTHORSHIP —— 反编译出来的 Java 里就是整句；
        //   2) R.string.authorship   —— 资源表里也有（App 里长按标题会弹出来）；
        //   3) assets/AUTHORSHIP.txt —— 解压 APK 第一层就能看到的纯文本。
        // 句子固定为「DeskBand <版本> 是 NinaTokyoo 于 <构建时刻> 在陕西西安完成的。」，
        // 时间由文件顶部的 [buildStamp] 给出（每次出包自动更新）。
        val authorshipLine =
            "DeskBand $vName 是 NinaTokyoo 于 $buildStamp 在陕西西安完成的。"
        buildConfigField("String", "AUTHORSHIP", "\"$authorshipLine\"")
        resValue("string", "authorship", authorshipLine)
        run {
            val dir = layout.buildDirectory.dir("generated/authorship").get().asFile
            dir.mkdirs()
            dir.resolve("AUTHORSHIP.txt").writeText(
                authorshipLine + "\n" +
                    "官方签名证书 SHA-256：77cd22901fc2286fc7fad8c1a7606344e123a2cb125b9cb64839f7bde35b69e9\n" +
                    "（从 apk-analysis 里核对出来的指纹；换密钥后要同步改这一行）\n",
                Charsets.UTF_8
            )
        }
        // 纯平台实现，不依赖 AndroidX / Material，包体小、构建面窄
    }

    // 签名配置。
    //
    // ⚠️ 口令**不写在这里**：这个文件是提交进仓库的，明文口令会随仓库一起公开。
    //    改从 local.properties 读（该文件已在 .gitignore 里），键名见下方注释；
    //    本地那份已经填好了，所以日常构建不受影响。
    //    如果 local.properties 里没有这几项（比如别人 clone 下来直接构建），
    //    签名配置会被跳过、release 产出未签名包 —— 不影响 assembleDebug 与单测。
    val signProps = Properties().apply {
        val f = rootProject.file("local.properties")
        if (f.exists()) f.inputStream().use { load(it) }
    }
    val signStore = signProps.getProperty("signing.storeFile")
        ?: System.getenv("DESKBAND_STORE_FILE")
    val signStorePwd = signProps.getProperty("signing.storePassword")
        ?: System.getenv("DESKBAND_STORE_PASSWORD")
    val signAlias = signProps.getProperty("signing.keyAlias")
        ?: System.getenv("DESKBAND_KEY_ALIAS")
    val signKeyPwd = signProps.getProperty("signing.keyPassword")
        ?: System.getenv("DESKBAND_KEY_PASSWORD")
    val canSign = signStore != null && signStorePwd != null &&
        signAlias != null && signKeyPwd != null

    signingConfigs {
        if (canSign) {
            create("petkey") {
                storeFile = rootProject.file(signStore!!)
                storePassword = signStorePwd
                keyAlias = signAlias
                keyPassword = signKeyPwd
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (canSign) signingConfig = signingConfigs.getByName("petkey")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            if (canSign) signingConfig = signingConfigs.getByName("petkey")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // 只有单元测试用 JUnit；App 本体仍是纯平台实现，不带任何运行时依赖
    testImplementation("junit:junit:4.13.2")
}
